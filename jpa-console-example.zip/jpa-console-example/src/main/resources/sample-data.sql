
INSERT INTO `carbrand` (`id`, `name`) VALUES (1, 'Ford');
INSERT INTO `carbrand` (`id`, `name`) VALUES (2, 'Chevrolet');
INSERT INTO `carbrand` (`id`, `name`) VALUES (3, 'Ferrari');

INSERT INTO `person` (`id`, `age`, `name`) VALUES (1, 32, 'John Doe');
INSERT INTO `person` (`id`, `age`, `name`) VALUES (2, 54, 'Mary Smith');
INSERT INTO `person` (`id`, `age`, `name`) VALUES (3, 20, 'Walter Dean');
	
INSERT INTO `car` (`id`, `year`, `brand_id`) VALUES (1, 2010, 1);
INSERT INTO `car` (`id`, `year`, `brand_id`) VALUES (2, 2000, 3);
INSERT INTO `car` (`id`, `year`, `brand_id`) VALUES (3, 1990, 2);
INSERT INTO `car` (`id`, `year`, `brand_id`) VALUES (4, 2011, 1);
INSERT INTO `car` (`id`, `year`, `brand_id`) VALUES (5, 1980, 3);
INSERT INTO `car` (`id`, `year`, `brand_id`) VALUES (6, 2001, 1);


INSERT INTO `person_car` (`Person_id`, `cars_id`) VALUES (1, 1);
INSERT INTO `person_car` (`Person_id`, `cars_id`) VALUES (1, 2);
INSERT INTO `person_car` (`Person_id`, `cars_id`) VALUES (2, 3);
INSERT INTO `person_car` (`Person_id`, `cars_id`) VALUES (3, 4);
INSERT INTO `person_car` (`Person_id`, `cars_id`) VALUES (3, 5);
INSERT INTO `person_car` (`Person_id`, `cars_id`) VALUES (3, 6);

